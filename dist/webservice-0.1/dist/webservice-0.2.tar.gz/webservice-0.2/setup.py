#!/usr/bin/python2.7

from setuptools import setup

setup(
    name='webservice', version='0.2', scripts=['webservice.py']
)
